import numpy as np

def save_data(team_name, data_points):
    for i in range(0,len(data_points)):
        pass
        